import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-warning-alert-one',
  templateUrl: './warning-alert-one.component.html',
  styleUrls: ['./warning-alert-one.component.css']
})
export class WarningAlertOneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
