import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-success-alert-one',
  templateUrl: './success-alert-one.component.html',
  styleUrls: ['./success-alert-one.component.css']
})
export class SuccessAlertOneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
