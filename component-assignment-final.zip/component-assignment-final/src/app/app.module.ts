import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { SuccessAlertOneComponent } from './success-alert-one/success-alert-one.component';
import { WarningAlertOneComponent } from './warning-alert-one/warning-alert-one.component';

@NgModule({
  declarations: [
    AppComponent,
    SuccessAlertOneComponent,
    WarningAlertOneComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
